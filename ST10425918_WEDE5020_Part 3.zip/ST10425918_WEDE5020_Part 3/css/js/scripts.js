// script.js — JavaScript for Youth Empowerment & Business Solutions Hub
// Author: Aphiwe Gans
// Created: 2025-09-19

// Fade-in animation on page load
document.addEventListener('DOMContentLoaded', function() {
    const body = document.body;
    body.style.opacity = '0';
    body.style.transition = 'opacity 1s ease-in-out';
    setTimeout(() => {
        body.style.opacity = '1';
    }, 100);
});

// Form validation for enquiry form
const enquiryForm = document.getElementById('enquiryForm');
if (enquiryForm) {
    enquiryForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const nameEl = document.getElementById('name');
        const emailEl = document.getElementById('email');
    const messageEl = document.getElementById('message');
    const typeEl = document.getElementById('message_type');
        const name = nameEl.value.trim();
        const email = emailEl.value.trim();
        const message = messageEl.value.trim();
        const resp = document.getElementById('enquiryResponse');

        if (!name || !email || !message || !typeEl || !typeEl.value) {
            resp.style.display = 'block';
            resp.style.color = 'red';
            resp.textContent = 'Please fill in all fields and select a message type.';
            return;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            resp.style.display = 'block';
            resp.style.color = 'red';
            resp.textContent = 'Please enter a valid email address.';
            return;
        }

    // Simulate submission (no backend) and show success message
        resp.style.display = 'block';
        resp.style.color = 'green';
        resp.textContent = 'Enquiry submitted successfully! We will respond shortly.';
        enquiryForm.reset();
    });
}

// Form validation for contact form
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const nameEl = document.getElementById('name');
        const emailEl = document.getElementById('email');
    const messageEl = document.getElementById('message');
    const typeEl = document.getElementById('message_type');
        const resp = document.getElementById('contactResponse');
        const name = nameEl.value.trim();
        const email = emailEl.value.trim();
        const message = messageEl.value.trim();

        if (!name || !email || !message || !typeEl || !typeEl.value) {
            resp.style.display = 'block';
            resp.style.color = 'red';
            resp.textContent = 'Please fill in all fields and select a message type.';
            return;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            resp.style.display = 'block';
            resp.style.color = 'red';
            resp.textContent = 'Please enter a valid email address.';
            return;
        }

        // Submit to Formspree endpoint configured on the form
        const action = contactForm.action;
        fetch(action, {
            method: 'POST',
            headers: { 'Accept': 'application/json' },
            body: new FormData(contactForm)
        }).then(response => {
            if (response.ok) {
                resp.style.display = 'block';
                resp.style.color = 'green';
                resp.textContent = 'Message sent successfully!';
                contactForm.reset();
            } else {
                return response.json().then(data => { throw data; });
            }
        }).catch(err => {
            resp.style.display = 'block';
            resp.style.color = 'red';
            resp.textContent = 'There was an error sending your message. Please try again later.';
        });
    });
}

// Image hover effect (additional enhancement)
const images = document.querySelectorAll('.logo img, .training-image, .event-image, .hero-image');
images.forEach(img => {
    img.addEventListener('mouseenter', function() {
        this.style.transform = 'scale(1.05)';
    });
    img.addEventListener('mouseleave', function() {
        this.style.transform = 'scale(1)';
    });
});

// Lightbox gallery for .gallery-img
document.addEventListener('DOMContentLoaded', function() {
    const galleryImgs = document.querySelectorAll('.gallery-img');
    if (galleryImgs.length) {
        const lightbox = document.createElement('div');
        lightbox.id = 'lightbox';
        lightbox.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.8);display:flex;align-items:center;justify-content:center;visibility:hidden;opacity:0;transition:opacity .2s;z-index:1000;';
        const img = document.createElement('img');
        img.style.maxWidth = '90%';
        img.style.maxHeight = '90%';
        lightbox.appendChild(img);
        document.body.appendChild(lightbox);

        galleryImgs.forEach(g => {
            g.style.cursor = 'zoom-in';
            g.addEventListener('click', () => {
                img.src = g.src;
                lightbox.style.visibility = 'visible';
                lightbox.style.opacity = '1';
            });
        });

        lightbox.addEventListener('click', () => {
            lightbox.style.opacity = '0';
            setTimeout(() => lightbox.style.visibility = 'hidden', 200);
        });
    }

    // Service filter: expects articles to have data-service attributes
    const serviceFilter = document.getElementById('service-filter');
    if (serviceFilter) {
        serviceFilter.addEventListener('change', function() {
            const value = this.value;
            const articles = document.querySelectorAll('main article');
            articles.forEach(a => {
                const svc = a.getAttribute('data-service') || 'all';
                if (value === 'all' || svc === value) {
                    a.style.display = '';
                } else {
                    a.style.display = 'none';
                }
            });
        });
    }
});
