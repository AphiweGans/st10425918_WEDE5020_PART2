# TODO List for Part 3 Implementation

- [x] Create js/ folder and move script.js to js/scripts.js
- [x] Update HTML links to js/scripts.js
- [x] Add meta descriptions to all HTML pages
- [x] Rename image files to descriptive names
- [x] Update image src in HTML files
- [ ] Implement lightbox gallery in services.html (HTML, CSS, JS)
- [ ] Add Google Maps embed to contact.html
- [ ] Add service filter to services.html (HTML, JS)
- [ ] Create robots.txt in root
- [ ] Create sitemap.xml in root
- [ ] Modify enquiry form: Add response div, update JS
- [ ] Change contact form to Formspree
- [ ] Update README with Part 3 section, changelog, references
- [ ] Test functionality
- [ ] Commit changes to GitHub
