# ST10425918_AphiweGans_WEDE5020_PART2

Youth Empowerment & Business Solutions Hub. 2025. Home - Youth Empowerment & Business Solutions Hub. [online]. Available at: file:///C:/Users/RC_Student_lab/OneDrive/css/index.html [Accessed 21 August 2025].

Youth Empowerment & Business Solutions Hub. 2025. About - Youth Empowerment & Business Solutions Hub. [online]. Available at: file:///C:/Users/RC_Student_lab/OneDrive/css/about.html [Accessed 21 August 2025].

Youth Empowerment & Business Solutions Hub. 2025. Contact - Youth Empowerment & Business Solutions Hub. [online]. file:///C:/Users/RC_Student_lab/OneDrive/css/contact.html [Accessed 21 August 2025].

Youth Empowerment & Business Solutions Hub. 2025. Enquiry - Youth Empowerment & Business Solutions Hub. [online]. Available at: file:///C:/Users/RC_Student_lab/OneDrive/css/enquiry.html [Accessed 21 August 2025].

Youth Empowerment & Business Solutions Hub. 2025. Services - Youth Empowerment & Business Solutions Hub. [online]. Available at: file:///C:/Users/RC_Student_lab/OneDrive/css/services.html [Accessed 21 August 2025].

## Changelog

## Part 2 Entries
- 2025-09-05 — Part2: Added external stylesheet (css/style.css) and linked to all pages. 
- 2025-09-06 — Base styles: Added CSS reset and :root variables. 
- 2025-09-07 — Typography: Added scale, responsive font sizes, and headings styles. 
- 2025-09-08 — Layout: Implemented CSS Grid two-column layout for desktop and stacked mobile layout. 
- 2025-09-09 — Navigation: Styled nav bar and added mobile stacking.
- 2025-09-10 — Responsive images: Added alt text and responsive image styles.
- 2025-09-11 — Accessibility: Added focus outlines and semantic HTML. 
- 2025-09-12 — Screenshots: Captured DevTools screenshots for desktop, tablet, mobile. 
- 2025-09-13 — Final polish: Updated README and completed rubric checklist. 

## Part 1 Entries
2025-09-22 - Added wireframe in the proposal.
2025-09-22 - Improved the content research and sourcing to be highly relevant, comprehensive and well-detailed.
2025-09-22 - Improved the website structure and planning to be more detailed.
2025-09-22 - Added changelog.
2025-09-22 - Improved website structure and planning to be more detailed.


## References:

Krug, S. 2014. Don’t make me think: A common sense approach to web usability. 3rd ed. San Francisco: New Riders.
Laudon, K.C. and Traver, C.G. 2021. E-commerce 2021: Business, technology, society. 16th ed. Harlow: Pearson.
Lidwell, W., Holden, K. and Butler, J. 2010. Universal principles of design. 2nd ed. Beverly: Rockport.
OECD. 2021. Entrepreneurship policies for youth in South Africa. [Online]. Available at: https://www.oecd.org [Accessed 26 August 2025].

# Youth Empowerment & Business Solutions Hub

## Overview
This project is a multi-page responsive website built for WEDE5020 POE Part 2. It showcases Youth Empowerment & Business Solutions Hub, including Home, About Us, Services, Enquiry, and Contact Us pages.

## Part 2 Summary
- External stylesheet (`css/style.css`) linked to all pages
- Base styles and CSS reset implemented
- Typography scaled with rem/em and responsive adjustments
- Layout uses CSS Grid and Flexbox
- Buttons, headings, and links styled with pseudo-classes
- Responsive design with breakpoints at 600px and 900px
- Navigation adapts for mobile
- Images are responsive with alt text
- Accessibility features: focus outlines, semantic HTML, labeled forms

## Screenshots



Tested on:
- Chrome
- Firefox
- Edge

## Breakpoints
- Mobile: ≤600px
- Tablet: 601px–900px
- Desktop: ≥901px



### How to test (manual)
1. Open `css/services.html` in a browser. The gallery should display as a responsive grid. Click an image to open the lightbox. Use the "Filter Services" dropdown to show different categories.
2. Open `css/contact.html`: confirm that the Google Map appears, select a Message Type, fill in fields, and submit. You should see an inline success or error message; if Formspree is configured, check your dashboard or email for the submission.
3. Open `css/enquiry.html`: same checks as contact — the map is present and submissions post to Formspree.
4. Try forms with JS disabled (browser devtools) — native form POST should still work (redirect/confirm depends on Formspree settings).

### Next steps / improvements (optional)
- Add keyboard support for lightbox (Esc to close, left/right to navigate if multi-image). — small JS change.
- Add a visible lightbox close button and alt/title for enlarged images.
- Add server-side form handling if you prefer not to use Formspree (Node/PHP example available).
- Generate a full sitemap with all pages and correct production URLs.






